import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-airport-table',
  templateUrl: './airport-table.component.html',
  styleUrls: ['./airport-table.component.scss']
})
export class AirportTableComponent implements OnInit {
  public airportDetails: any = [];
  public pagination: object;
  public filteredArray;
  public searchText;
  public small: string;
  public medium: string;
  public large: string;
  public heliport: string;
  public closed: string;
  public isSmallChecked: boolean = false;
  public isMediumChecked: boolean = false;
  public isLargeChecked: boolean = false;
  public isHeliportChecked: boolean = false;
  public isClosedChecked: boolean = false;
  public users;
  public properties;
  public selectedFilter = [];
  public textFilter: boolean = false;
  public smallFilter: boolean;
  public mediumFilter: boolean;
  public largeFilter: boolean;
  public heliportFilter: boolean;
  public closedFilter: boolean;
  public searchFilterArray = [];
  public smallFilterArray = [];
  public mediumFilterArray = [];
  public largeFilterArray = [];
  public heliportFilterArray = [];
  public closedFilterArray = [];
  constructor(private http: HttpClient) { }

  ngOnInit(): void {
    this.pagination = {
      itemsPerPage: 4,
      currentPage: 1,
    }
    this.http.get('assets/data/airports.json').subscribe(res => {
      this.airportDetails = res;
      this.filteredArray = [...this.airportDetails];
      this.pagination['totalItems'] = this.filteredArray?.length;
      this.users = [...this.airportDetails]; 
      this.properties = Object.keys(this.users[0]);
    })


  }

  pageChanged(event: any) {
    this.pagination['currentPage'] = event;
  }
  filterArray() {
    if (this.searchText !== '' && !undefined) {
      this.textFilter = true
    }
    else {
      this.textFilter = false
    }
    if (!this.airportDetails.length) {
      this.filteredArray = [];
      return;
    }

    if (!this.searchText || this.searchText == '') {
      this.filteredArray = [...this.airportDetails];
      return;
    }

    const index = this.properties.indexOf('type');
    if (index > -1) {
      this.properties.splice(index, 1);
    }


    if (this.selectedFilter.length) {
      this.selectedFilter = this.selectedFilter.filter((user) => {
        return this.properties.find((property) => {
          const valueString = user[property]?.toString().toLowerCase();
          return valueString?.includes(this.searchText.toLowerCase())
        }
        ) ? user : null;
      })
    }
    else {
      this.filteredArray = this.users.filter((user) => {
        return this.properties.find((property) => {
          const valueString = user[property]?.toString().toLowerCase();
          return valueString?.includes(this.searchText.toLowerCase())
        }
        ) ? user : null;
      });
      this.selectedFilter = [...this.filteredArray];
    }
    this.searchFilterArray = this.filteredArray;
    this.checkSelectedFilter();
  }
  isMediumSelected() {
    this.isMediumChecked = !this.isMediumChecked;
    if (this.isMediumChecked) {
      this.mediumFilter = true;
      if (this.textFilter && this.selectedFilter.length) {
        this.selectedFilter = this.selectedFilter.filter(data => {
          return data.type == 'medium';
        })
      }
      else {
        this.filteredArray = this.users.filter(data => {
          return data.type == 'medium';
        })
        for (let index of this.filteredArray) {
          this.selectedFilter = this.filteredArray.filter(data => {
            return data.id !== index.id;
          })
        }

      }
      this.mediumFilterArray = this.selectedFilter;
    } else {

      this.mediumFilter = false;
      if (this.textFilter) {
        this.selectedFilter = [...this.searchFilterArray];
      }
      else {
        this.selectedFilter = this.airportDetails;
        this.mediumFilterArray = [];
       
      }

    }



    this.checkSelectedFilter();

  }
  isSmallSelected() {
    this.isSmallChecked = !this.isSmallChecked;
    if (this.isSmallChecked) {
      this.smallFilter = true;
      if (this.textFilter && this.selectedFilter.length) {
        this.selectedFilter = this.selectedFilter.filter(data => {
          return data.type == 'small';
        })
      }
      else {
        this.filteredArray = this.users.filter(data => {
          return data.type == 'small';
        })
        for (let index of this.filteredArray) {
          this.selectedFilter = this.filteredArray.filter(data => {
            return data.id !== index.id;
          })
        }

        this.smallFilterArray = this.selectedFilter;
      }
    }
    else {
      this.smallFilter = false;
      if (this.textFilter) {
        this.selectedFilter = [...this.searchFilterArray];
      }
      else {
        this.selectedFilter = this.airportDetails;
        this.smallFilterArray = [];
      }
    }

    this.checkSelectedFilter();

  }
  isLargeSelected() {
    this.isLargeChecked = !this.isLargeChecked;
    if (this.isLargeChecked) {
      this.largeFilter = true;
      if (this.textFilter && this.selectedFilter.length) {
        this.selectedFilter = this.selectedFilter.filter(data => {
          return data.type == 'large';
        })
      }
      else {
        this.filteredArray = this.users.filter(data => {
          return data.type == 'large';
        })
        for (let index of this.filteredArray) {
          this.selectedFilter = this.filteredArray.filter(data => {
            return data.id !== index.id;
          })
        }

        this.largeFilterArray = this.selectedFilter;
      }
    }
    else {
      this.smallFilter = false;
      if (this.textFilter) {
        this.selectedFilter = [...this.searchFilterArray];
      }
      else {
        this.selectedFilter = this.airportDetails;
        this.largeFilterArray = [];
      }
    }

    this.checkSelectedFilter();

  }
  isHeliportSelected() {
    this.isHeliportChecked = !this.isHeliportChecked;
    if (this.isHeliportChecked) {
      this.heliportFilter = true;
      if (this.textFilter && this.selectedFilter.length) {
        this.selectedFilter = this.selectedFilter.filter(data => {
          return data.type == 'heliport';
        })
      }
      else {
        this.filteredArray = this.users.filter(data => {
          return data.type == 'heliport';
        })
        for (let index of this.filteredArray) {
          this.selectedFilter = this.filteredArray.filter(data => {
            return data.id !== index.id;
          })
        }

        this.heliportFilterArray = this.selectedFilter;
      }
    }
    else {
      this.smallFilter = false;
      if (this.textFilter) {
        this.selectedFilter = [...this.searchFilterArray];
      }
      else {
        this.selectedFilter = this.airportDetails;
        this.heliportFilterArray = [];
      }
    }

    this.checkSelectedFilter();

  }
  isClosedSelected() {
    this.isClosedChecked = !this.isClosedChecked;
    if (this.isClosedChecked) {
      this.closedFilter = true;
      if (this.textFilter && this.selectedFilter.length) {
        this.selectedFilter = this.selectedFilter.filter(data => {
          return data.type == 'closed';
        })
      }
      else {
        this.filteredArray = this.users.filter(data => {
          return data.type == 'closed';
        })
        for (let index of this.filteredArray) {
          this.selectedFilter = this.filteredArray.filter(data => {
            return data.id !== index.id;
          })
        }

        this.closedFilterArray = this.selectedFilter;
      }
    }
    else {
      this.smallFilter = false;
      if (this.textFilter) {
        this.selectedFilter = [...this.searchFilterArray];
      }
      else {
        this.selectedFilter = this.airportDetails;
        this.closedFilterArray = [];
      }
    }

    this.checkSelectedFilter();

  }
  checkSelectedFilter() {
    if (this.smallFilterArray.length && this.mediumFilterArray.length && this.largeFilterArray.length && this.heliportFilterArray.length 
      && this.closedFilterArray.length) {
   
     let set = new Set([...this.smallFilterArray,...this.mediumFilterArray,...this.largeFilterArray,...this.heliportFilterArray,...this.closedFilterArray]);
     this.filteredArray = [...set];

    }

    else {
      this.filteredArray = [...this.selectedFilter];
    }


  }
}
