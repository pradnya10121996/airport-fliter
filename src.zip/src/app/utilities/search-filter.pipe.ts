import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'searchFilter'
})
export class SearchFilterPipe implements PipeTransform {

  transform(value: any, inputSearch?: any, typeSmall?: any, typeMedium?: any, typeLarge?: any, typeHeliport?: any, typeClosed?: any, colName: any = "type"): unknown {
    if (!value) return null;
    if (!inputSearch && !typeSmall && !typeMedium && !typeLarge && !typeHeliport && !typeClosed) return value;

    inputSearch = inputSearch?.toLowerCase();

    if (typeSmall == 'small') {
      return value.filter((data: any) => {
        return data[colName].toLowerCase().includes(typeSmall);
      })
    }

    else if (typeMedium == 'medium') {
      return value.filter((data: any) => {
        return data[colName].toLowerCase().includes(typeMedium);
      })
    }

    else if (typeLarge == 'large') {
      return value.filter((data: any) => {
        return data[colName].toLowerCase().includes(typeLarge);
      })
    }

    else if (typeHeliport == 'heliport') {
      return value.filter((data: any) => {
        return data[colName].toLowerCase().includes(typeHeliport);
      })
    }

    else if (typeClosed == 'closed') {
      return value.filter((data: any) => {
        return data[colName].toLowerCase().includes(typeClosed);
      })
    }

    return value.filter(function (data: any) {
      return JSON.stringify(data).toLowerCase().includes(inputSearch);
    });

  }

}
